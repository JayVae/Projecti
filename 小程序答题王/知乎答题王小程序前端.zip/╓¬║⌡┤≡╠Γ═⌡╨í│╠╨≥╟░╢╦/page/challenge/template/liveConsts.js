module.exports.ChallengeStatus = {
    ChallengeStatusNon: 1,
    ChallengeStatusReady: 2,
    ChallengeStatusChallenge: 3,
    ChallengeStatusRun: 4,
    ChallengeStatusEnd: 5,
    ChallengeStatusExpired: -1
};