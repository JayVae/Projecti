function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

var t = function() {
    function e(e, t) {
        for (var a = 0; a < t.length; a++) {
            var i = t[a];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
            Object.defineProperty(e, i.key, i);
        }
    }
    return function(t, a, i) {
        return a && e(t.prototype, a), i && e(t, i), t;
    };
}(), a = require("./../../../util/util.js"), i = require("./../../../net/fightNet.js"), n = (require("./../../../net/connectNotify.js"), 
require("./../../../const/notifyConsts.js")), r = require("./../../../const/consts"), s = require("./../../../util/Tween.js"), o = require("./../../../libs/md5/md5.js"), l = getApp(), c = function() {
    function c(t) {
        e(this, c), this.page = t, this.name = "StateChoose", this.selected = {
            a: !1,
            b: !1
        }, this.emptyAnswer = {
            option: 0,
            yes: !1,
            score: 0,
            answer: 0,
            totalScore: 0
        };
    }
    return t(c, [ {
        key: "init",
        value: function() {
            if (this.round = this.page.round, this.roomID = this.page.roomId, this.page.answerBtnLock = !1, 
            this.countDown = this.page.data.battleViewData.countDown, this.preTime = a.getServerTime(), 
            this.timeFlag = setInterval(this.onTimer.bind(this), 100), this.page.playerLogout) this.page.stateChange("StateChooseEnd"); else {
                var e = !0, t = !1, i = void 0;
                try {
                    for (var r, s = this.page.answerList[Symbol.iterator](); !(e = (r = s.next()).done); e = !0) {
                        var o = r.value;
                        o.num == this.round && this.onFightAnswer(n.ActionFightAnswer, o);
                    }
                } catch (e) {
                    t = !0, i = e;
                } finally {
                    try {
                        !e && s.return && s.return();
                    } finally {
                        if (t) throw i;
                    }
                }
                this.playTimeAni(this.countDown);
            }
        }
    }, {
        key: "checkEnd",
        value: function() {
            !this.isEnd && this.selected.a && this.selected.b && this.waitCmd && console.log("稀有情况发生啦！", this.isEnd, this.selected.a, this.selected.b, this.waitCmd), 
            !this.isEnd && this.selected.a && this.selected.b && !this.waitCmd && (this.stopTimeAni(), 
            this.page.stateChange("StateChooseEnd"));
        }
    }, {
        key: "getScoreBarHeight",
        value: function(e) {
            return 100 * Math.min(e / 1200, 1) + "%";
        }
    }, {
        key: "onFightAnswer",
        value: function(e, t) {
            var a = "ob" != this.page.type && "obChallenge" != this.page.type;
            t.uid == this.page.data.a.uid ? this.abSelect(t, "a", a) : t.uid == this.page.data.b.uid && this.abSelect(t, "b", a);
        }
    }, {
        key: "abSelect",
        value: function(e, t, a) {
            var i = this;
            if (!this.selected[t]) {
                this.selected[t] = !0;
                var n = e.option - 1, r = e.yes;
                this.page.selectIndex[this.round][t] = n, e.answer > 0 && this.page.setTrueIndex(this.round, e.answer - 1);
                var s = {};
                if (s = this.playBuffAni(e, s, t), s = this.playAddScore(t, e.totalScore, s), !r) {
                    var o = wx.createAnimation();
                    o.backgroundColor("#fff").step({
                        timingFunction: "step-start",
                        duration: 100
                    }), o.backgroundColor("#F2594B").step({
                        timingFunction: "ease-in",
                        duration: 200,
                        delay: 400
                    }), s[t + ".scoreProgressAni"] = o.export();
                }
                a ? setTimeout(function() {
                    i.checkEnd();
                }, 500) : this.checkEnd(), this.page.setData(s);
            }
        }
    }, {
        key: "mySelect",
        value: function(e) {
            var t = this, a = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            if (this.page.answerBtnLock = !0, e >= 0) {
                this.tapEffPlaying = !0;
                var i = s.fastGet("tapEff" + this.round);
                i.call(function() {
                    var a = wx.createAnimation();
                    a.scale(1.1).step({
                        timingFunction: "ease-in",
                        duration: 150
                    }), a.scale(1).step({
                        timingFunction: "linear",
                        duration: 50
                    });
                    var i = {};
                    i["battleViewData.answer[" + e + "].ani"] = a, i["battleViewData.answer[" + e + "].className"] = "selected", 
                    t.page.setData(i);
                }), i.wait(500), i.call(function() {
                    a || (t.tapEffPlaying = !1, t.playChooseAni());
                });
            }
            this.choose(e, a);
        }
    }, {
        key: "choose",
        value: function(e, t) {
            var n = this;
            this.clearCmdTimeout(), t || (this.page.selectIndex[this.round].a = e, this.selected.a = !0);
            var s = e + 1;
            this.waitCmd = !0, this.cmdData = void 0;
            var c = "";
            try {
                var u = [];
                u.push(this.page.data.battleViewData.answer[0].answer), u.push(this.page.data.battleViewData.answer[1].answer), 
                u.push(this.page.data.battleViewData.answer[2].answer), u.push(this.page.data.battleViewData.answer[3].answer), 
                u.sort(function(e, t) {
                    return e > t ? 1 : -1;
                }), c = u[0] + u[1] + u[2] + u[3], c = o.hex_md5(c);
            } catch (e) {}
            i.choose(this.roomID, this.round, s, c, this.page.cfTime, a.getServerTime(), function(a, i) {
                if (a) console.error("choose err", a), a.errCode == r.ExitCode.RequestErr && n.countDown > 2 ? n.cmdTimeout = setTimeout(function() {
                    n.isEnd || n.choose(e, t), n.cmdTimeout = void 0;
                }, 2e3) : (n.cmdData = void 0, n.waitCmd = !1, t || (n.page.selectIndex[n.round].a = -1, 
                n.playChooseAni()), n.clearCmdTimeout()); else if (i && i.answer > 0 && n.page.setTrueIndex(n.round, i.answer - 1), 
                n.cmdData = i, n.waitCmd = !1, t) n.page.audienceViewController && s > 0 && n.page.audienceViewController.remindAnswer(l.mainData.role.userInfo.nickName, n.page.data.battleViewData.answer[s - 1].answer), 
                n.checkEnd(); else {
                    if (i.enemyAnswer > 0 && !n.selected.b) {
                        console.log("对手短连接传来的答题");
                        var o = i.enemyAnswer - 1, c = {
                            option: i.enemyAnswer,
                            yes: n.page.getTrueIndex(n.round) == o,
                            totalScore: i.enemyScore,
                            answer: 0
                        };
                        n.abSelect(c, "b", !1);
                    }
                    n.page.selectIndex[n.round].a = i.option - 1, n.playChooseAni();
                }
            });
        }
    }, {
        key: "onTimer",
        value: function() {
            var e = this, t = a.getServerTime() - this.preTime;
            this.preTime = a.getServerTime(), this.countDown = Math.max(0, this.countDown - t / 1e3);
            var n = {
                "battleViewData.countDownStr": Math.ceil(this.countDown),
                "battleViewData.countDown": this.countDown
            };
            this.page.setData(n), this.countDown <= 0 && (clearInterval(this.timeFlag), this.timeFlag = void 0, 
            this.page.answerBtnLock = !0, "obChallenge" == this.page.type ? (a.log("~~~getAnswer.curTime:", a.formatTime(a.getServerTimeBaseSecond()), "/num:", this.page.round), 
            a.log("getAnswer.endtime:", a.formatTime(this.page.endTime), "/num:", this.page.round), 
            i.getAnswer(this.roomID, this.round, function(t, a) {
                t ? console.error("getAnswer err", t) : a && (console.log("getAnswer data", a), 
                a.answer > 0 && e.page.setTrueIndex(e.round, a.answer - 1), e.selected.a && e.selected.b && e.checkEnd(), 
                e.selected.a || e.abSelect(e.emptyAnswer, "a", !1), e.selected.b || e.abSelect(e.emptyAnswer, "b", !1));
            })) : "ob" == this.page.type ? (this.selected.a || this.abSelect(this.emptyAnswer, "a", !1), 
            this.selected.b || this.abSelect(this.emptyAnswer, "b", !1)) : (this.selected.a || this.waitCmd || this.mySelect(-1), 
            this.selected.b || this.abSelect(this.emptyAnswer, "b", !1)));
        }
    }, {
        key: "clearCmdTimeout",
        value: function() {
            this.cmdTimeout && (clearTimeout(this.cmdTimeout), this.cmdTimeout = void 0);
        }
    }, {
        key: "playChooseAni",
        value: function() {
            if (!this.tapEffPlaying && !this.waitCmd) if (this.page.selectIndex[this.round].a >= 0 && this.cmdData) {
                var e = this.cmdData.yes, t = (this.page.data.a.score, this.cmdData.score, {});
                e ? (this.page.audioTrueCtx && this.page.audioTrueCtx.play(), t = this.playTrueAni(t), 
                t = this.playBuffAni(this.cmdData, t, "a")) : (this.page.audioFalseCtx && this.page.audioFalseCtx.play(), 
                t = this.playFalseAni(t), t = this.playErrEff(t)), this.checkEnd(), this.page.setData(t);
            } else this.checkEnd();
        }
    }, {
        key: "playTrueAni",
        value: function(e) {
            var t = this.page.selectIndex[this.round].a;
            return e["battleViewData.answer[" + t + "].className"] = "true", e["battleViewData.answer[" + t + "].lImg"] = 2, 
            e = this.playAddScore("a", this.cmdData.score + this.page.data.a.score, e);
        }
    }, {
        key: "playFalseAni",
        value: function(e) {
            var t = this.page.selectIndex[this.round].a;
            return e["battleViewData.answer[" + t + "].className"] = "false", e["battleViewData.answer[" + t + "].lImg"] = 1, 
            e;
        }
    }, {
        key: "playBuffAni",
        value: function(e, t, a) {
            if (e.extraScore) {
                var i = ~~e.extraScore[5], n = ~~e.extraScore[6], r = 204e3 + this.page.data.battleViewData.typeID;
                if (i > 0 || n > 0) if ("a" == a) {
                    var s = wx.createAnimation();
                    s.left("-8rpx").step({
                        timingFunction: "ease-in",
                        duration: 500
                    }), s.left("-400rpx").step({
                        timingFunction: "ease-in",
                        duration: 200,
                        delay: 2500
                    }), i > 0 && (t["battleViewData.buffScoreLeft"] = "+" + i), n > 0 && (t["battleViewData.bookScoreLeft"] = "+" + n), 
                    t["battleViewData.bookTypeLeft"] = r, t["battleViewData.leftComboViewAni"] = s.export();
                } else {
                    var o = wx.createAnimation();
                    o.right("-8rpx").step({
                        timingFunction: "ease-in",
                        duration: 500
                    }), o.right("-400rpx").step({
                        timingFunction: "ease-in",
                        duration: 200,
                        delay: 2500
                    }), i > 0 && (t["battleViewData.buffScoreRight"] = "+" + i), n > 0 && (t["battleViewData.bookScoreRight"] = "+" + n), 
                    t["battleViewData.bookTypeRight"] = r, t["battleViewData.rightComboViewAni"] = o.export();
                }
            }
            return t;
        }
    }, {
        key: "playErrEff",
        value: function(e) {
            var t = this, a = s.fastGet("fullShade");
            a.call(function() {
                var e = wx.createAnimation();
                e.backgroundColor("rgba(232,232,232,0.6)").step({
                    timingFunction: "step-start",
                    duration: 100
                }), e.backgroundColor("rgba(232,126,126,0.5)").step({
                    timingFunction: "step-start",
                    duration: 100
                }), e.backgroundColor("rgba(232,126,126,0)").step({
                    timingFunction: "linear",
                    duration: 1e3
                });
                var a = {};
                a["battleViewData.fullShadeAni"] = e.export(), t.page.setData(a);
            }), a.wait(1200), a.call(function() {
                t.page.setData({
                    "battleViewData.fullShadeVisible": !1
                });
            }), (a = s.fastGet("mainViewAni")).call(function() {
                var e = {}, a = wx.createAnimation();
                a.left("5rpx").top("-5rpx").step({
                    timingFunction: "linear",
                    duration: 50
                }), e["battleViewData.mainViewAni"] = a.export(), t.page.setData(e);
            }), a.wait(50), a.call(function() {
                var e = {}, a = wx.createAnimation();
                a.left("-5rpx").top("5rpx").step({
                    timingFunction: "linear",
                    duration: 50
                }), e["battleViewData.mainViewAni"] = a.export(), t.page.setData(e);
            }), a.wait(50), a.call(function() {
                var e = {}, a = wx.createAnimation();
                a.left("5rpx").top("-5rpx").step({
                    timingFunction: "linear",
                    duration: 50
                }), e["battleViewData.mainViewAni"] = a.export(), t.page.setData(e);
            }), a.wait(50), a.call(function() {
                var e = {}, a = wx.createAnimation();
                a.left("-5rpx").top("5rpx").step({
                    timingFunction: "linear",
                    duration: 50
                }), e["battleViewData.mainViewAni"] = a.export(), t.page.setData(e);
            }), a.wait(50), a.call(function() {
                var e = {}, a = wx.createAnimation();
                a.left("0px").top("0px").step({
                    timingFunction: "linear",
                    duration: 50
                }), e["battleViewData.mainViewAni"] = a.export(), t.page.setData(e);
            });
            var i = wx.createAnimation();
            return i.backgroundColor("#fff").step({
                timingFunction: "step-start",
                duration: 100
            }), i.backgroundColor("#F2594B").step({
                timingFunction: "ease-in",
                duration: 200,
                delay: 400
            }), e["a.scoreProgressAni"] = i.export(), e["battleViewData.fullShadeVisible"] = !0, 
            e;
        }
    }, {
        key: "playAddScore",
        value: function(e, t, a) {
            var i = this, n = this.page.data[e].score, r = t - n;
            if (r > 0) {
                a[e + ".score"] = t;
                var o = wx.createAnimation();
                o.height(this.getScoreBarHeight(t)).step({
                    timingFunction: "ease-in",
                    duration: 300
                }), a[e + ".scoreProgressViewAni"] = o.export();
                var l = s.fastGet(e + "AddScore");
                l.call(function() {
                    var t = wx.createAnimation();
                    t.scale(1.4).step({
                        timingFunction: "ease-in",
                        duration: 100
                    });
                    var a = {};
                    a[e + ".scoreAni"] = t.export(), i.page.setData(a);
                }), l.tweenCall(function(t) {
                    var a = {};
                    a[e + ".scoreStr"] = Math.ceil(n + r * t), i.page.setData(a);
                }, 300), l.call(function() {
                    var a = {};
                    a[e + ".scoreStr"] = t;
                    var n = wx.createAnimation();
                    n.scale(1).step({
                        timingFunction: "ease-in",
                        duration: 100
                    }), a[e + ".scoreAni"] = n.export(), i.page.setData(a);
                });
            }
            return a;
        }
    }, {
        key: "playTimeAni",
        value: function(e) {
            var t = {}, a = Math.max(0, e - 5), i = Math.max(0, e - a);
            if (a > 0) {
                var n = wx.createAnimation();
                n.rotateZ(180).step({
                    timingFunction: "linear",
                    duration: 1e3 * a,
                    transformOrigin: "0% 50%",
                    delay: 0
                }), t["battleViewData.ovalViewRight"] = n.export();
            }
            var r = wx.createAnimation();
            r.rotateZ(180).step({
                timingFunction: "linear",
                duration: 1e3 * i,
                transformOrigin: "100% 50%",
                delay: 1e3 * a
            }), t["battleViewData.ovalViewLeft"] = r.export(), this.page.setData(t);
        }
    }, {
        key: "stopTimeAni",
        value: function() {
            var e = Math.max(0, this.countDown - 5), t = Math.max(0, this.countDown - e), a = e >= 5 ? 0 : 180 * (5 - e) / 5, i = t >= 5 ? 0 : 180 * (5 - t) / 5, n = wx.createAnimation();
            n.rotateZ(a).step({
                timingFunction: "step-start",
                duration: 0,
                delay: 0,
                transformOrigin: "0% 50%"
            });
            var r = wx.createAnimation();
            r.rotateZ(i).step({
                timingFunction: "step-start",
                duration: 0,
                delay: 0,
                transformOrigin: "100% 50%"
            });
            var s = {};
            s["battleViewData.ovalViewLeft"] = r.export(), s["battleViewData.ovalViewRight"] = n.export(), 
            this.page.setData(s);
        }
    }, {
        key: "update",
        value: function(e) {}
    }, {
        key: "end",
        value: function(e) {
            this.isEnd = !0, this.timeFlag && (clearTimeout(this.timeFlag), this.timeFlag = void 0), 
            this.clearCmdTimeout();
        }
    }, {
        key: "onPlayerLogout",
        value: function() {
            this.isEnd || this.page.stateChange("StateChooseEnd");
        }
    } ]), c;
}();

module.exports = c;